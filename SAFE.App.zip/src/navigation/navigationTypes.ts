// src/navigation/navigationTypes.ts

export type RootStackParamList = {
  Login: undefined;
  Tabs: undefined;
};
